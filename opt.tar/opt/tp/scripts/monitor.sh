#!/bin/bash

        if pgrep -x "sshd"
        then
        echo "El proceso ssh esta funcionando"
        else
        exec echo "El proceso ssh no esta activo" | mail -s "ADVERTENCIA" root
        echo "El proceso de ssh no esta activo "
        fi
        
        
        if pgrep -x "apache2" > /dev/null
        then
        echo "El proceso apache2 esta funcionando"
        else

        exec echo "El proceso apache2 no esta activo" | mail -s "ADVERTENCIA" root
        echo "El proceso de mysql no esta activo "
        fi
        
        
        if pgrep -x "mysqld"
        then
        echo "El proceso esta funcionando"
        else
        exec echo "El proceso mysql no esta activo" | mail -s "ADVERTENCIA" root
        echo "El proceso de mysql no esta activo"
        fi

exit 1;