#!/bin/bash

read -p "Ingrese dia, mes y anio en formato MM/DD/AAAA:" DATE
date "+%m-%d-%Y" -d "${DATE}" > /dev/null  2>&1
if [ $? != 0 ];
then
    echo La fecha "${DATE}" NO es un formato valido
    exit 1
fi

esLaborable(){
DIASEMANA=$(date -d "$DATE" +'%A')

if [[ "$DIASEMANA" == "Saturday" ]] || [[ "$DIASEMANA" == "Sunday" ]]; 
 then echo "Es fin de semana. Dia no laborable." 
fi

Y=$(date -d "${DATE}" +'%Y')
FERIADOT1="06/17/$Y"
FERIADOTDIA=$(date -d "$FERIADOT1" +'%A')

if [ "$FERIADOTDIA" == "Tuesday" ];
    then 
    FERNUEVO0="$(date --date="$FERIADOT1 -8days" +%m/%d/%Y)"
        if [ "$DATE" == "$FERNUEVO0" ];
        then 
            echo "Es feriado por Paso a la inmmortalidad del Gral.Guemes."
        fi
fi
if [ "$FERIADOTDIA" == "Wednesday" ];
    then
    FERNUEVO1="$(date --date="$FERIADOT1 -9days" +%m/%d/%Y)"
        if [ "$DATE" == "$FERNUEVO1" ];
        then 
            echo "Es feriado por Paso a la inmmortalidad del Gral.Guemes."
        fi
fi
if [ "$FERIADOTDIA" == "Thursday" ];
    then 
    FERNUEVO2="$(date --date="$FERIADOT1 +4days" +%m/%d/%Y)"
        if [ "$DATE" == "$FERNUEVO2" ];
        then 
            echo "Es feriado por Paso a la inmmortalidad del Gral.Guemes."
        fi
fi
if [ "$FERIADOTDIA" == "Friday" ];
    then 
    FERNUEVO3="$(date --date="$FERIADOT1 +3days" +%m/%d/%Y)"
        if [ "$DATE" == "$FERNUEVO3" ];
        then 
            echo "Es feriado por Paso a la inmmortalidad del Gral.Guemes."
        fi
fi
FERIADOT2="08/17/$Y"
FERIADOTDIA2=$(date -d "$FERIADOT2" +'%A')

if [ "$FERIADOTDIA2" == "Tuesday" ];
    then 
    FERNUEVO4="$(date --date="$FERIADOT2 -8days" +%m/%d/%Y)"
        if [ "$DATE" == "$FERNUEVO4" ];
        then 
            echo "Es feriado por Paso a la inmmortalidad del Gral.Guemes."
        fi
fi
if [ "$FERIADOTDIA2" == "Wednesday" ];
    then
    FERNUEVO5="$(date --date="$FERIADOT2 -9days" +%m/%d/%Y)" 
        if [ "$DATE" == "$FERNUEVO5" ];
        then 
            echo "Es feriado por Paso a la inmmortalidad del Gral.Guemes."
        fi
fi
if [ "$FERIADOTDIA2" == "Thursday" ];
    then 
    FERNUEVO6="$(date  --date="$FERIADOT2 +4days" +%m/%d/%Y)"
        if [ "$DATE" == "$FERNUEVO6" ];
        then 
            echo "Es feriado por Paso a la inmmortalidad del Gral.Guemes."
        fi
fi
if [ "$FERIADOTDIA2" == "Friday" ];
    then 
    FERNUEVO7="$(date --date="$FERIADOT2 +3days" +%m/%d/%Y)"
        if [ "$DATE" = "$FERNUEVO7" ];
        then 
            echo "Es feriado por Paso a la inmmortalidad del Gral.Guemes."
        fi
fi
FERIADOT3="10/12/$Y"
FERIADOTDIA3=$(date -d "$FERIADOT3" +'%A')

if [ "$FERIADOTDIA3" == "Tuesday" ];
    then 
    FERNUEVO8="$(date --date "$FERIADOT3 -8days" +%m/%d/%Y)"
        if [ "$DATE" == "$FERNUEVO8" ];
        then 
            echo "Es feriado por Dia de Respeto a la Diversidad Cultural."
        fi
fi
if [ "$FERIADOTDIA3" == "Wednesday" ];
    then
    FERNUEVO9="$(date --date="$FERIADOT3 -9days" +%m/%d/%Y)"
        if [ "$DATE" == "$FERNUEVO9" ];
        then 
            echo "Es feriado por Dia de Respeto a la Diversidad Cultural."
        fi
fi
if [ "$FERIADOTDIA3" == "Thursday" ];
    then 
    FERNUEVO10="$(date --date="$FERIADOT3 +4days" +%m/%d/%Y)"
        if [ "$DATE" == "$FERNUEVO10" ];
        then 
            echo "Es feriado por Dia de Respeto a la Diversidad Cultural."
        fi
fi
if [ "$FERIADOTDIA3" == "Friday" ];
    then 
    FERNUEVO11="$(date --date="$FERIADOT3 +3days" +%m/%d/%Y)"
        if [ "$DATE" == "$FERNUEVO11" ];
        then 
            echo "Es feriado por Dia de Respeto a la Diversidad Cultural."
        fi
fi
FERIADOT4="11/20/$Y"
FERIADOTDIA4=$(date -d "$FERIADOT4" +'%A')

if [ "$FERIADOTDIA4" == "Tuesday" ];
    then 
    FERNUEVO12="$(date --date="$FERIADOT4 -8days" +%m/%d/%Y)"
        if [ "$DATE" == "$FERNUEVO12" ];
        then 
            echo "Es feriado por Dia de la Soberania Nacional."
        fi
fi
if [ "$FERIADOTDIA4" == "Wednesday" ];
    then
    FERNUEVO13="$(date --date="$FERIADOT4 -9days" +%m/%d/%Y)"
        if [ "$DATE" == "$FERNUEVO13" ];
        then 
            echo "Es feriado por Dia de la Soberania Nacional."
        fi
fi
if [ "$FERIADOTDIA4" == "Thursday" ];
    then 
    FERNUEVO14="$(date --date="$FERIADOT4 +4days" +%m/%d/%Y)"
        if [ "$DATE" == "$FERNUEVO14" ];
        then 
            echo "Es feriado por Dia de la Soberania Nacional."
        fi
fi
if [ "$FERIADOTDIA4" == "Friday" ];
    then 
    FERNUEVO15="$(date --date="$FERIADOT4 +3days" +%m/%d/%Y)"
        if [ "$DATE" == "$FERNUEVO15" ];
        then 
            echo "Es feriado por Dia de la Soberania Nacional."
        fi
fi
if [ "$DATE" == "01/01/$Y" ];
then
    echo "La fecha ${DATE} es A�o Nuevo."
fi

if [[ "$DATE" == "02/15/$Y" || $DATE == "02/16/$Y" ]];
then
    echo "La fecha ${DATE} es Carnaval."
fi

if [ "$DATE" == "03/24/$Y" ];
then
    echo "La fecha ${DATE} es Dia Nacional de la Memoria por la Verdad y la Justicia."
fi
if [ "$DATE" == "04/02/$Y" ];
then
    echo "La fecha ${DATE} es D�a del Veterano y de los Ca�dos en la Guerra de Malvinas."
fi
if [ "$DATE" == "05/01/$Y" ];
then
    echo "La fecha ${DATE} es Dia del Trabajador." 
fi
if [ "$DATE" == "05/25/$Y" ];
then
    echo "La fecha ${DATE} es Dia de la Revolucion de Mayo."
fi
if [ "$DATE" == "06/20/$Y" ];
then
    echo "La fecha ${DATE} es D�a del Paso a la Inmortalidad del General Manuel Belgrano."
fi
if [ "$DATE" == "07/09/$Y" ];
then
    echo "La fecha ${DATE} es D�a de la Independencia."
fi
if [ "$DATE" == "12/25/$Y" ];
then
    echo "La fecha ${DATE} es Navidad."
fi
}

esLaborable "$DATE"
exit 0;